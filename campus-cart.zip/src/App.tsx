import React, { useState, useEffect, useRef } from 'react';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  getDocs 
} from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth, logOut, handleFirestoreError, OperationType } from './lib/firebase';
import { Listing, UserProfile, TabType, ToastMessage, ListingCategory, ListingCondition } from './types';
import { INITIAL_SEED_LISTINGS } from './utils/seedData';

// Components
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SellForm } from './components/SellForm';
import { SearchAndFilters } from './components/SearchAndFilters';
import { ListingCard } from './components/ListingCard';
import { AuthModal } from './components/AuthModal';
import { MessageModal } from './components/MessageModal';
import { ToastContainer } from './components/Toast';
import { Footer } from './components/Footer';

export default function App() {
  // Auth state
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authActionText, setAuthActionText] = useState('Sign in to continue');
  const [domainError, setDomainError] = useState<string | null>(null);

  // Listings & Filter state
  const [listings, setListings] = useState<Listing[]>([]);
  const [loadingListings, setLoadingListings] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ListingCategory | 'All'>('All');
  const [activeTab, setActiveTab] = useState<TabType>('all');

  // Favourites state (persisted in localStorage)
  const [favouriteIds, setFavouriteIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('campus_cart_favourites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Selected listing for messaging modal
  const [messagingListing, setMessagingListing] = useState<Listing | null>(null);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const hasSeededRef = useRef(false);

  // Helper to show toasts
  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  // Persist favourites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('campus_cart_favourites', JSON.stringify(favouriteIds));
    } catch (e) {
      console.error('Failed to save favourites to localStorage:', e);
    }
  }, [favouriteIds]);

  // Handle Auth State Changes & Domain Restriction
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const email = firebaseUser.email || '';
        const isVitStudent = email.toLowerCase().endsWith('@vitstudent.ac.in');

        if (!isVitStudent) {
          // Domain violation: Sign out immediately and display sticky note error
          await logOut();
          setUser(null);
          setDomainError(
            `Account (${email}) is not a @vitstudent.ac.in email address. Campus Cart is strictly restricted to VIT students.`
          );
          setAuthActionText('VIT Student Sign In Required');
          setAuthModalOpen(true);
        } else {
          // Valid VIT student email
          setDomainError(null);
          const nameParts = (firebaseUser.displayName || 'Student').split(' ');
          const firstName = nameParts[0];

          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName || 'VIT Student',
            firstName,
            photoURL: firebaseUser.photoURL,
          });

          showToast(`Welcome back, ${firstName}!`, 'success');
        }
      } else {
        setUser((prev) => (prev?.uid === 'demo-guest-id' ? prev : null));
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time Firestore Listings Subscription
  useEffect(() => {
    setLoadingListings(true);
    const path = 'listings';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const fetchedListings: Listing[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            name: data.name || '',
            category: data.category || 'Other',
            price: data.price || 0,
            condition: data.condition || 'Good',
            description: data.description || '',
            imageBase64: data.imageBase64 || undefined,
            createdAt: data.createdAt || Date.now(),
            sellerId: data.sellerId || 'unknown',
            sellerName: data.sellerName || 'Anonymous Peer',
            sellerPhoto: data.sellerPhoto || undefined,
          };
        });

        setListings(fetchedListings);
        setLoadingListings(false);

        // Auto-seed initial 3 realistic listings if database is brand new and empty
        if (fetchedListings.length === 0 && !hasSeededRef.current) {
          hasSeededRef.current = true;
          seedDatabase();
        }
      },
      (error) => {
        setLoadingListings(false);
        console.error('Firestore subscription error:', error);
      }
    );

    return () => unsubscribe();
  }, []);

  // Seed database helper
  const seedDatabase = async () => {
    try {
      showToast('Initializing campus feed with sample items...', 'info');
      for (const item of INITIAL_SEED_LISTINGS) {
        await addDoc(collection(db, 'listings'), item);
      }
    } catch (err) {
      console.error('Failed to seed initial listings:', err);
    }
  };

  // Demo Guest Mode enable handler
  const handleEnableDemoMode = () => {
    setUser({
      uid: 'demo-guest-id',
      email: 'guest@vitstudent.ac.in',
      displayName: 'Rahul Sharma (Guest)',
      firstName: 'Rahul',
      photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    });
    setDomainError(null);
    showToast('Entered Demo Guest Mode as Rahul! You can post and message items.', 'success');
  };

  // Toggle Favourite
  const handleToggleFavourite = (id: string) => {
    setFavouriteIds((prev) => {
      const exists = prev.includes(id);
      if (exists) {
        showToast('Removed from favourites', 'info');
        return prev.filter((item) => item !== id);
      } else {
        showToast('Added to favourites!', 'success');
        return [...prev, id];
      }
    });
  };

  // Submit New Listing
  const handleCreateListing = async (newListingData: {
    name: string;
    category: ListingCategory;
    price: number;
    condition: ListingCondition;
    description: string;
    imageBase64?: string;
  }) => {
    if (!user) {
      setAuthActionText('Sign in to post your item for sale');
      setAuthModalOpen(true);
      return;
    }

    try {
      const payload = {
        name: newListingData.name,
        category: newListingData.category,
        price: newListingData.price,
        condition: newListingData.condition,
        description: newListingData.description,
        imageBase64: newListingData.imageBase64 || null,
        createdAt: Date.now(),
        sellerId: user.uid,
        sellerName: user.firstName,
        sellerPhoto: user.photoURL || null,
      };

      await addDoc(collection(db, 'listings'), payload);
      showToast('Your listing is live on the campus feed!', 'success');

      // Smooth scroll down to listings grid
      setTimeout(() => {
        const el = document.getElementById('listings-section');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 200);

    } catch (err) {
      console.error('Failed to create listing:', err);
      showToast('Error posting listing. Please check connection.', 'error');
    }
  };

  // Delete Listing
  const handleDeleteListing = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'listings', id));
      showToast('Listing removed from marketplace.', 'info');
    } catch (err) {
      console.error('Failed to delete listing:', err);
      showToast('Could not delete listing.', 'error');
    }
  };

  // Share Listing handler
  const handleShareListing = async (listing: Listing) => {
    const shareUrl = window.location.href.split('#')[0] + `#listing-${listing.id}`;
    const shareText = `${listing.name} — ₹${listing.price}, ${listing.condition}. Check it out on Campus Cart: ${shareUrl}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: listing.name,
          text: shareText,
          url: shareUrl,
        });
        showToast('Shared successfully!', 'success');
        return;
      } catch (e) {
        // User cancelled or share failed, fallback to clipboard
      }
    }

    // Fallback: Copy to clipboard
    try {
      await navigator.clipboard.writeText(shareText);
      showToast('Listing link copied to clipboard!', 'success');
    } catch (err) {
      showToast('Copied share text to clipboard', 'info');
    }
  };

  // Handle "Message seller" click
  const handleMessageSellerClick = (listing: Listing) => {
    if (!user) {
      setAuthActionText(`Sign in to message ${listing.sellerName}`);
      setAuthModalOpen(true);
      return;
    }
    setMessagingListing(listing);
  };

  // Filtering Logic
  const filteredListings = listings.filter((item) => {
    // 1. Tab filter
    if (activeTab === 'favourites') {
      if (!favouriteIds.includes(item.id)) return false;
    } else if (activeTab === 'my-listings') {
      if (!user || item.sellerId !== user.uid) return false;
    }

    // 2. Category filter
    if (selectedCategory !== 'All' && item.category !== selectedCategory) {
      return false;
    }

    // 3. Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchCat) return false;
    }

    return true;
  });

  const myListingsCount = user
    ? listings.filter((item) => item.sellerId === user.uid).length
    : 0;

  return (
    <div className="min-h-screen flex flex-col selection:bg-[#FFD93D] selection:text-[#1B3A5C]">
      
      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))} />

      {/* Auth Modal with Domain Restriction */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        domainError={domainError}
        onEnableDemoMode={handleEnableDemoMode}
        actionText={authActionText}
      />

      {/* Seller Message Modal */}
      <MessageModal
        listing={messagingListing}
        currentUser={user}
        onClose={() => setMessagingListing(null)}
        onShowToast={showToast}
      />

      {/* Navbar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalListingsCount={listings.length}
        favouritesCount={favouriteIds.length}
        myListingsCount={myListingsCount}
        onOpenAuth={(txt) => {
          setAuthActionText(txt || 'Sign in to access student features');
          setAuthModalOpen(true);
        }}
        onSignOut={async () => {
          await logOut();
          setUser(null);
          showToast('Signed out successfully.', 'info');
        }}
        onScrollToSell={() => {
          const el = document.getElementById('sell-section');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Hero Section */}
      <Hero
        onBrowseClick={() => {
          const el = document.getElementById('listings-section');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Sell an Item Form */}
      <SellForm
        user={user}
        onSubmitListing={handleCreateListing}
        onOpenAuth={(txt) => {
          setAuthActionText(txt || 'Sign in to post an item for sale');
          setAuthModalOpen(true);
        }}
      />

      {/* Search, Filter & Counter Bar */}
      <SearchAndFilters
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalLiveCount={listings.length}
        favouritesCount={favouriteIds.length}
        myListingsCount={myListingsCount}
        isSignedIn={!!user}
      />

      {/* Listings Grid */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        {loadingListings ? (
          <div className="py-16 text-center">
            <div className="inline-block w-8 h-8 border-4 border-[#1B3A5C] border-t-[#E63946] rounded-full animate-spin mb-3"></div>
            <p className="text-sm font-bold text-[#1B3A5C]">Loading real-time campus listings...</p>
          </div>
        ) : filteredListings.length === 0 ? (
          <div className="py-16 px-4 text-center bg-white/80 border-2 border-dashed border-[#1B3A5C]/20 rounded-2xl max-w-md mx-auto my-8 transform -rotate-0.5 shadow-sm">
            <div className="w-12 h-12 bg-[#FFD93D] border-2 border-[#1B3A5C] rounded-2xl mx-auto mb-3 flex items-center justify-center text-xl">
              📌
            </div>
            <h3 className="text-lg font-extrabold text-[#1B3A5C]">No listings found</h3>
            <p className="text-xs text-[#1B3A5C]/70 mt-1 mb-4">
              {activeTab === 'favourites'
                ? "You haven't added any favourites yet. Click the heart icon on any card!"
                : activeTab === 'my-listings'
                ? "You haven't posted any listings yet. Use the sell form above to post one!"
                : "No items match your search or filter criteria."}
            </p>
            {(searchQuery || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 bg-[#E63946] text-white font-bold text-xs rounded-full border border-[#1B3A5C] hover:bg-[#E63946]/90 cursor-pointer"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredListings.map((item, idx) => (
              <ListingCard
                key={item.id}
                listing={item}
                isFavourite={favouriteIds.includes(item.id)}
                onToggleFavourite={handleToggleFavourite}
                currentUser={user}
                onMessageSeller={handleMessageSellerClick}
                onShareListing={handleShareListing}
                onDeleteListing={handleDeleteListing}
                index={idx}
              />
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer />

    </div>
  );
}
