export type ListingCategory = 'Books' | 'Cycles' | 'Electronics' | 'Other';
export type ListingCondition = 'Like New' | 'Good' | 'Fair';

export interface Listing {
  id: string;
  name: string;
  category: ListingCategory;
  price: number;
  condition: ListingCondition;
  description: string;
  imageBase64?: string;
  createdAt: number; // Unix timestamp in ms
  sellerId: string;
  sellerName: string;
  sellerPhoto?: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  firstName: string;
  photoURL: string | null;
}

export type TabType = 'all' | 'favourites' | 'my-listings';

export interface ToastMessage {
  id: string;
  text: string;
  type: 'success' | 'info' | 'error';
}
