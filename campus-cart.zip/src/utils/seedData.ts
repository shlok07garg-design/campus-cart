import { Listing } from '../types';

export const INITIAL_SEED_LISTINGS: Omit<Listing, 'id'>[] = [
  {
    name: "Data Structures & Algorithms in C++ (4th Ed)",
    category: "Books",
    price: 450,
    condition: "Good",
    description: "Standard textbook for CSE 2nd year. Minimal pencil highlighting, all pages intact. Great for CS201 exams.",
    imageBase64: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2, // 2 days ago
    sellerId: "seed-seller-1",
    sellerName: "Ananya",
    sellerPhoto: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Hero Hawk 21-Speed Hybrid Bicycle",
    category: "Cycles",
    price: 3200,
    condition: "Good",
    description: "Serviced last month with new brake pads. Comes with sturdy combination lock & bell. Smooth ride between MH and SJT.",
    imageBase64: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=600&q=80",
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 1, // 1 day ago
    sellerId: "seed-seller-2",
    sellerName: "Rohan",
    sellerPhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Casio FX-991EX ClassWiz Calculator",
    category: "Electronics",
    price: 850,
    condition: "Like New",
    description: "Barely used for 1 semester. Dual solar & battery power, supports matrix & polynomial calculations. Original cover included.",
    imageBase64: "https://images.unsplash.com/photo-1611125832047-1d7ad1e8e48a?auto=format&fit=crop&w=600&q=80",
    createdAt: Date.now() - 1000 * 60 * 60 * 3, // 3 hours ago
    sellerId: "seed-seller-3",
    sellerName: "Priya",
    sellerPhoto: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80"
  }
];
