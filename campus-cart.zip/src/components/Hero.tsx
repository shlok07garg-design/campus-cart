import React from 'react';
import { ArrowDown, Tag, ShieldCheck, Clock } from 'lucide-react';

interface HeroProps {
  onBrowseClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBrowseClick }) => {
  return (
    <section className="relative py-12 sm:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden text-center max-w-5xl mx-auto">
      
      {/* Scattered Sticky Notes around the Hero */}
      <div 
        className="absolute top-4 left-4 sm:left-10 hidden sm:flex items-center gap-1.5 px-3.5 py-2 bg-[#FFD93D] text-[#1B3A5C] text-xs font-bold rounded-lg border-2 border-[#1B3A5C] sticky-note-shadow transform -rotate-6 transition-transform hover:rotate-0"
      >
        <Tag className="w-3.5 h-3.5 text-[#E63946]" />
        <span>2nd-hand ✓</span>
      </div>

      <div 
        className="absolute top-8 right-4 sm:right-12 hidden sm:flex items-center gap-1.5 px-3.5 py-2 bg-[#FFD93D] text-[#1B3A5C] text-xs font-bold rounded-lg border-2 border-[#1B3A5C] sticky-note-shadow transform rotate-4 transition-transform hover:rotate-0"
      >
        <ShieldCheck className="w-3.5 h-3.5 text-[#1B3A5C]" />
        <span>No fees</span>
      </div>

      <div 
        className="absolute bottom-6 right-16 hidden md:flex items-center gap-1.5 px-3.5 py-2 bg-[#FFD93D] text-[#1B3A5C] text-xs font-bold rounded-lg border-2 border-[#1B3A5C] sticky-note-shadow transform -rotate-3 transition-transform hover:rotate-0"
      >
        <Clock className="w-3.5 h-3.5 text-[#E63946]" />
        <span>Same day pickup</span>
      </div>

      {/* Main Headline */}
      <div className="relative inline-block mb-4">
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold text-[#1B3A5C] tracking-tight leading-tight">
          Sell it. Find it. <br className="hidden sm:inline" />
          <span className="marker-underline text-[#1B3A5C]">
            Campus only.
          </span>
        </h1>
      </div>

      {/* Mobile Sticky Note Badges (visible on small screens) */}
      <div className="flex sm:hidden justify-center gap-2 my-4 flex-wrap">
        <span className="px-2.5 py-1 bg-[#FFD93D] text-[#1B3A5C] text-[11px] font-bold rounded-md border border-[#1B3A5C] transform -rotate-2">
          2nd-hand ✓
        </span>
        <span className="px-2.5 py-1 bg-[#FFD93D] text-[#1B3A5C] text-[11px] font-bold rounded-md border border-[#1B3A5C] transform rotate-2">
          No fees
        </span>
        <span className="px-2.5 py-1 bg-[#FFD93D] text-[#1B3A5C] text-[11px] font-bold rounded-md border border-[#1B3A5C] transform -rotate-1">
          Same day pickup
        </span>
      </div>

      {/* One-line subheading */}
      <p className="mt-4 text-base sm:text-xl text-[#1B3A5C]/80 font-medium max-w-2xl mx-auto leading-relaxed">
        The official student-to-student notebook marketplace for used textbooks, campus cycles, calculators, and electronics.
      </p>

      {/* CTA Button */}
      <div className="mt-8 flex justify-center">
        <button
          onClick={onBrowseClick}
          className="group px-8 py-4 bg-[#E63946] text-white font-extrabold text-base sm:text-lg rounded-full border-2 border-[#1B3A5C] shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-1 active:translate-y-0 flex items-center gap-2 cursor-pointer"
        >
          <span>Browse listings</span>
          <ArrowDown className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
        </button>
      </div>

      {/* Notebook margin divider line */}
      <div className="mt-12 border-b-2 border-dashed border-[#1B3A5C]/20 max-w-xl mx-auto"></div>
    </section>
  );
};
