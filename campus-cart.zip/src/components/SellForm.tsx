import React, { useState, useRef } from 'react';
import { ListingCategory, ListingCondition, UserProfile } from '../types';
import { compressAndConvertToBase64 } from '../utils/imageCompressor';
import { Send, Upload, Image as ImageIcon, Loader2, Sparkles } from 'lucide-react';

interface SellFormProps {
  user: UserProfile | null;
  onSubmitListing: (listingData: {
    name: string;
    category: ListingCategory;
    price: number;
    condition: ListingCondition;
    description: string;
    imageBase64?: string;
  }) => Promise<void>;
  onOpenAuth: (actionText?: string) => void;
}

const CATEGORIES: ListingCategory[] = ['Books', 'Cycles', 'Electronics', 'Other'];
const CONDITIONS: ListingCondition[] = ['Like New', 'Good', 'Fair'];

export const SellForm: React.FC<SellFormProps> = ({ user, onSubmitListing, onOpenAuth }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ListingCategory>('Books');
  const [price, setPrice] = useState<string>('');
  const [condition, setCondition] = useState<ListingCondition>('Good');
  const [description, setDescription] = useState('');
  
  const [imageBase64, setImageBase64] = useState<string | undefined>(undefined);
  const [isCompressing, setIsCompressing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const compressed = await compressAndConvertToBase64(file, 720, 0.7);
      setImageBase64(compressed);
    } catch (err) {
      console.error('Image compression failed:', err);
    } finally {
      setIsCompressing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      onOpenAuth('Sign in to post your item for sale');
      return;
    }

    if (!name.trim() || !price || parseFloat(price) <= 0) return;

    try {
      setIsSubmitting(true);
      await onSubmitListing({
        name: name.trim(),
        category,
        price: parseFloat(price),
        condition,
        description: description.trim(),
        imageBase64,
      });

      // Reset form on success
      setName('');
      setPrice('');
      setDescription('');
      setImageBase64(undefined);
      if (fileInputRef.current) fileInputRef.current.value = '';

    } catch (err) {
      console.error('Failed to post listing:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="sell-section" className="py-8 px-4 sm:px-6 lg:px-8 max-w-2xl mx-auto">
      <div 
        className="relative bg-[#FAFBFC] coupon-border rounded-2xl p-6 sm:p-8 shadow-xl transition-all"
        style={{ transform: 'rotate(0.2deg)' }}
      >
        {/* Cut-out coupon corner dots */}
        <div className="absolute -top-3 left-6 w-6 h-6 bg-[#FAFBFC] border-b-2 border-r-2 border-[#1B3A5C]/30 rounded-full"></div>
        <div className="absolute -bottom-3 right-6 w-6 h-6 bg-[#FAFBFC] border-t-2 border-l-2 border-[#1B3A5C]/30 rounded-full"></div>

        {/* Header */}
        <div className="flex items-center justify-between mb-6 border-b-2 border-dashed border-[#1B3A5C]/20 pb-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">✂️</span>
            <h2 className="text-2xl font-extrabold text-[#1B3A5C]">
              Sell an item
            </h2>
          </div>
          <span className="text-xs font-bold text-[#E63946] bg-[#FFD93D] px-2.5 py-1 rounded-md border border-[#1B3A5C]/30">
            Campus Voucher
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Item Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
              Item Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Algorithms Textbook (4th Ed) or Hero Bicycle"
              className="w-full px-4 py-2.5 bg-white border-2 border-[#1B3A5C]/20 rounded-xl text-[#1B3A5C] text-sm focus:outline-none focus:border-[#E63946] transition-colors"
            />
          </div>

          {/* Category Chips */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
              Category *
            </label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => {
                const isSelected = category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#E63946] text-white border-2 border-[#1B3A5C] shadow-xs'
                        : 'bg-white text-[#1B3A5C] border-2 border-[#1B3A5C]/30 hover:border-[#1B3A5C]'
                    }`}
                  >
                    {cat === 'Books' && '📚 '}
                    {cat === 'Cycles' && '🚲 '}
                    {cat === 'Electronics' && '⚡ '}
                    {cat === 'Other' && '📦 '}
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Price & Condition */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Price */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
                Price in Rupees (₹) *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-[#E63946]">₹</span>
                <input
                  type="number"
                  required
                  min="0"
                  step="1"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="e.g. 450"
                  className="w-full pl-8 pr-4 py-2.5 bg-white border-2 border-[#1B3A5C]/20 rounded-xl text-[#1B3A5C] text-sm font-bold focus:outline-none focus:border-[#E63946]"
                />
              </div>
            </div>

            {/* Condition Chips */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
                Condition *
              </label>
              <div className="flex flex-wrap gap-1.5">
                {CONDITIONS.map((cond) => {
                  const isSelected = condition === cond;
                  return (
                    <button
                      key={cond}
                      type="button"
                      onClick={() => setCondition(cond)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#E63946] text-white border-2 border-[#1B3A5C] shadow-xs'
                          : 'bg-white text-[#1B3A5C] border-2 border-[#1B3A5C]/30 hover:border-[#1B3A5C]'
                      }`}
                    >
                      {cond}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Short Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
              Short Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Minimal highlights, used for 1 semester, works perfectly..."
              className="w-full px-4 py-2.5 bg-white border-2 border-[#1B3A5C]/20 rounded-xl text-[#1B3A5C] text-sm focus:outline-none focus:border-[#E63946] resize-none"
            />
          </div>

          {/* Photo Upload */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
              Item Photo (Optional)
            </label>
            
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#1B3A5C]/30 hover:border-[#E63946] rounded-xl p-4 bg-white text-center cursor-pointer transition-colors group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />

              {isCompressing ? (
                <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#E63946] py-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Compressing image paper-plane style...</span>
                </div>
              ) : imageBase64 ? (
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={imageBase64}
                      alt="Preview"
                      className="w-12 h-12 object-cover rounded-lg border border-[#1B3A5C]/20"
                    />
                    <div className="text-left">
                      <p className="text-xs font-bold text-[#1B3A5C]">Photo Attached ✓</p>
                      <p className="text-[10px] text-[#1B3A5C]/60">Compressed & ready for instant save</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setImageBase64(undefined);
                      if (fileInputRef.current) fileInputRef.current.value = '';
                    }}
                    className="text-xs text-[#E63946] font-bold hover:underline"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center gap-1.5 py-1 text-[#1B3A5C]/70 group-hover:text-[#E63946]">
                  <Upload className="w-5 h-5" />
                  <p className="text-xs font-semibold">
                    Click or drag photo here to attach
                  </p>
                  <p className="text-[10px] text-[#1B3A5C]/50">Auto-compressed client side</p>
                </div>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || isCompressing}
              className="w-full py-3.5 px-6 bg-[#E63946] text-white font-extrabold text-base rounded-full border-2 border-[#1B3A5C] hover:bg-[#E63946]/90 transition-all transform active:scale-98 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Posting to Campus Feed...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>{user ? 'Post Listing Live' : 'Sign in & Post Listing'}</span>
                </>
              )}
            </button>
          </div>

        </form>
      </div>
    </section>
  );
};
