import React from 'react';
import { Heart, Sparkles } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t-2 border-[#1B3A5C]/20 bg-[#FAFBFC]/80 backdrop-blur-xs py-8 px-4 text-center">
      <div className="max-w-4xl mx-auto space-y-3">
        
        {/* Notebook margin double line decoration */}
        <div className="border-b border-dashed border-[#1B3A5C]/20 max-w-xs mx-auto mb-4"></div>

        <p className="font-handwriting text-2xl font-bold text-[#1B3A5C] flex items-center justify-center gap-2">
          <span>Built live at the</span>
          <span className="marker-underline text-[#1B3A5C] px-1">
            VinnovateIT Vibe Coding Workshop
          </span>
        </p>

        <p className="text-xs text-[#1B3A5C]/70 font-medium max-w-md mx-auto">
          The official student-to-student marketplace for books, cycles, and campus electronics.
        </p>

        <div className="pt-2 text-[11px] text-[#1B3A5C]/50 flex items-center justify-center gap-1.5">
          <span>Campus Cart © {new Date().getFullYear()}</span>
          <span>•</span>
          <span>VIT Campus Community</span>
        </div>

      </div>
    </footer>
  );
};
