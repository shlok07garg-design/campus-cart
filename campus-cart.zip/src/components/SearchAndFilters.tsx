import React, { useState, useEffect } from 'react';
import { ListingCategory, TabType } from '../types';
import { Search, Heart, Package, Grid, X } from 'lucide-react';

interface SearchAndFiltersProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: ListingCategory | 'All';
  setSelectedCategory: (cat: ListingCategory | 'All') => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  totalLiveCount: number;
  favouritesCount: number;
  myListingsCount: number;
  isSignedIn: boolean;
}

const CATEGORIES: (ListingCategory | 'All')[] = ['All', 'Books', 'Cycles', 'Electronics', 'Other'];

export const SearchAndFilters: React.FC<SearchAndFiltersProps> = ({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  activeTab,
  setActiveTab,
  totalLiveCount,
  favouritesCount,
  myListingsCount,
  isSignedIn,
}) => {
  // Animated Counter: counts up visibly from 0 to totalLiveCount
  const [displayedCount, setDisplayedCount] = useState(0);

  useEffect(() => {
    let start = displayedCount;
    const end = totalLiveCount;
    if (start === end) return;

    const duration = 600; // ms
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const current = Math.floor(start + (end - start) * progress);
      setDisplayedCount(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setDisplayedCount(end);
      }
    };

    requestAnimationFrame(animate);
  }, [totalLiveCount]);

  return (
    <div id="listings-section" className="py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
      
      {/* Top Header Row: Counter & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-[#1B3A5C]/15 pb-4">
        
        {/* Animated Live Counter */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center min-w-[2.5rem] h-10 px-3 bg-[#E63946] text-white font-black text-lg rounded-xl border-2 border-[#1B3A5C] shadow-xs transform -rotate-1">
            {displayedCount}
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-[#1B3A5C] tracking-tight">
              Live Campus Listings
            </h2>
            <p className="text-xs text-[#1B3A5C]/70">
              Updated in real-time from students
            </p>
          </div>
        </div>

        {/* Tab Controls: All / Favourites / My Listings */}
        <div className="flex items-center gap-1.5 bg-[#C9E2F5]/30 p-1 rounded-full border border-[#1B3A5C]/20 self-start sm:self-auto">
          
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'all'
                ? 'bg-[#E63946] text-white shadow-xs'
                : 'text-[#1B3A5C] hover:bg-[#1B3A5C]/5'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>All listings</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'all' ? 'bg-white/20 text-white' : 'bg-[#1B3A5C]/10 text-[#1B3A5C]'
            }`}>
              {totalLiveCount}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('favourites')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'favourites'
                ? 'bg-[#E63946] text-white shadow-xs'
                : 'text-[#1B3A5C] hover:bg-[#1B3A5C]/5'
            }`}
          >
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>My favourites</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'favourites' ? 'bg-white/20 text-white' : 'bg-[#1B3A5C]/10 text-[#1B3A5C]'
            }`}>
              {favouritesCount}
            </span>
          </button>

          {isSignedIn && (
            <button
              onClick={() => setActiveTab('my-listings')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'my-listings'
                  ? 'bg-[#E63946] text-white shadow-xs'
                  : 'text-[#1B3A5C] hover:bg-[#1B3A5C]/5'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>My listings</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeTab === 'my-listings' ? 'bg-white/20 text-white' : 'bg-[#1B3A5C]/10 text-[#1B3A5C]'
              }`}>
                {myListingsCount}
              </span>
            </button>
          )}

        </div>

      </div>

      {/* Search Bar: paper-white pill shape */}
      <div className="relative max-w-2xl mx-auto">
        <div className="relative flex items-center">
          <Search className="absolute left-4 w-5 h-5 text-[#1B3A5C]/50 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for books, cycles, electronics…"
            className="w-full pl-11 pr-10 py-3.5 bg-white border-2 border-[#1B3A5C]/25 rounded-full text-[#1B3A5C] text-sm placeholder-[#1B3A5C]/50 font-medium focus:outline-none focus:border-[#E63946] shadow-sm transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 p-1 text-[#1B3A5C]/60 hover:text-[#1B3A5C] rounded-full hover:bg-[#1B3A5C]/10 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Filter Chips: All / Books / Cycles / Electronics / Other */}
      <div className="flex items-center justify-center gap-2 flex-wrap pt-1">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#E63946] text-white border-2 border-[#1B3A5C] shadow-xs transform scale-105'
                  : 'bg-white text-[#1B3A5C] border-2 border-[#1B3A5C]/20 hover:border-[#1B3A5C] hover:bg-[#FAFBFC]'
              }`}
            >
              {cat === 'All' && '✨ All'}
              {cat === 'Books' && '📚 Books'}
              {cat === 'Cycles' && '🚲 Cycles'}
              {cat === 'Electronics' && '⚡ Electronics'}
              {cat === 'Other' && '📦 Other'}
            </button>
          );
        })}
      </div>

    </div>
  );
};
