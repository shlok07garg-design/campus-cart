import React from 'react';
import { X, Lock, CheckCircle, AlertTriangle } from 'lucide-react';
import { signInWithGoogle } from '../lib/firebase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  domainError?: string | null;
  onEnableDemoMode: () => void;
  actionText?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  domainError,
  onEnableDemoMode,
  actionText = "Sign in to continue"
}) => {
  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      console.error('Sign in error:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B3A5C]/40 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-md bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl p-6 shadow-2xl transition-all"
        style={{ transform: 'rotate(-0.5deg)' }}
      >
        {/* Paper pushpin decoration */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-[#E63946] border-2 border-white shadow-md flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#1B3A5C]/60 hover:text-[#1B3A5C] p-1.5 rounded-xl hover:bg-[#1B3A5C]/5"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mt-2 mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-[#FFD93D] border-2 border-[#1B3A5C] rounded-2xl mb-3 shadow-xs transform -rotate-3">
            <Lock className="w-6 h-6 text-[#1B3A5C]" />
          </div>
          <h3 className="text-xl font-bold text-[#1B3A5C]">Student Verification</h3>
          <p className="text-sm text-[#1B3A5C]/80 mt-1">{actionText}</p>
        </div>

        {/* Domain Error Sticky Note */}
        {domainError ? (
          <div className="mb-6 p-4 bg-[#FFD93D] border-2 border-[#1B3A5C] rounded-xl text-left relative shadow-md transform -rotate-1">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#E63946] flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-[#1B3A5C] text-sm">
                  This marketplace is for VIT students only
                </h4>
                <p className="text-xs text-[#1B3A5C]/90 mt-1 leading-relaxed">
                  {domainError}
                </p>
                <button
                  onClick={() => {
                    onEnableDemoMode();
                    onClose();
                  }}
                  className="mt-3 text-xs font-bold text-[#E63946] underline hover:text-[#1B3A5C] cursor-pointer"
                >
                  Continue as Guest Student (Demo Mode) →
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="mb-6 p-3.5 bg-[#C9E2F5]/30 border border-[#1B3A5C]/20 rounded-xl text-xs text-[#1B3A5C] flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-[#E63946] flex-shrink-0" />
            <span>Must use your <strong>@vitstudent.ac.in</strong> email address to sign in.</span>
          </div>
        )}

        <div className="space-y-3">
          <button
            onClick={handleGoogleSignIn}
            className="w-full py-3 px-4 bg-[#E63946] text-white font-bold rounded-full border-2 border-[#1B3A5C] hover:bg-[#E63946]/90 transition-transform active:scale-95 shadow-md flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            Sign in with VIT Google Account
          </button>

          <button
            onClick={() => {
              onEnableDemoMode();
              onClose();
            }}
            className="w-full py-2.5 px-4 bg-[#FAFBFC] text-[#1B3A5C] text-xs font-semibold rounded-full border border-[#1B3A5C]/30 hover:bg-[#1B3A5C]/5 transition-colors"
          >
            Explore as Guest Demo User
          </button>
        </div>

        <p className="text-[11px] text-center text-[#1B3A5C]/60 mt-4">
          By signing in, you agree to buy and sell exclusively with verified campus peers.
        </p>
      </div>
    </div>
  );
};
