import React from 'react';
import { ToastMessage } from '../types';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full px-4 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-center justify-between gap-3 p-3.5 bg-[#FAFBFC] border-2 border-[#1B3A5C]/20 rounded-2xl shadow-xl transition-all duration-300 animate-slide-up"
          style={{
            transform: 'rotate(-0.5deg)',
            backgroundColor: toast.type === 'error' ? '#FFF5F5' : '#FAFBFC',
          }}
        >
          <div className="flex items-center gap-2.5 text-[#1B3A5C]">
            {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#E63946] flex-shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-5 h-5 text-[#E63946] flex-shrink-0" />}
            {toast.type === 'info' && <Info className="w-5 h-5 text-[#1B3A5C] flex-shrink-0" />}
            <p className="text-sm font-medium leading-snug">{toast.text}</p>
          </div>
          <button
            onClick={() => onDismiss(toast.id)}
            className="text-[#1B3A5C]/60 hover:text-[#1B3A5C] p-1 rounded-lg hover:bg-[#1B3A5C]/5"
            aria-label="Close notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
