import React, { useState } from 'react';
import { Listing, UserProfile } from '../types';
import { Heart, Share2, MessageCircle, Trash2, BookOpen, Bike, Zap, Package, User } from 'lucide-react';

interface ListingCardProps {
  listing: Listing;
  isFavourite: boolean;
  onToggleFavourite: (id: string) => void;
  currentUser: UserProfile | null;
  onMessageSeller: (listing: Listing) => void;
  onShareListing: (listing: Listing) => void;
  onDeleteListing?: (id: string) => void;
  index: number;
}

export const ListingCard: React.FC<ListingCardProps> = ({
  listing,
  isFavourite,
  onToggleFavourite,
  currentUser,
  onMessageSeller,
  onShareListing,
  onDeleteListing,
  index,
}) => {
  const [imageError, setImageError] = useState(false);

  // Slight random tilt for pinned corkboard index-card effect
  const tilts = ['-rotate-1', 'rotate-1', '-rotate-2', 'rotate-0.5', '-rotate-0.5'];
  const cardTilt = tilts[index % tilts.length];

  const isSeller = currentUser && listing.sellerId === currentUser.uid;

  // Category Icon helper
  const renderCategoryIcon = (category: string) => {
    switch (category) {
      case 'Books':
        return <BookOpen className="w-10 h-10 text-[#1B3A5C]/40" />;
      case 'Cycles':
        return <Bike className="w-10 h-10 text-[#1B3A5C]/40" />;
      case 'Electronics':
        return <Zap className="w-10 h-10 text-[#1B3A5C]/40" />;
      default:
        return <Package className="w-10 h-10 text-[#1B3A5C]/40" />;
    }
  };

  return (
    <div
      className={`group relative bg-[#FAFBFC] border-2 border-[#1B3A5C]/25 rounded-2xl p-4 shadow-md transition-all duration-300 hover:shadow-2xl hover:-translate-y-1.5 flex flex-col justify-between ${cardTilt}`}
      style={{
        borderRadius: '16px',
      }}
    >
      {/* Paper pushpin doodle at top center */}
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-[#E63946] border-2 border-white shadow-xs z-20 flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
      </div>

      <div>
        {/* Top Bar: Sticky-note Category Tag + Heart Favourite & Share icons */}
        <div className="flex items-center justify-between mb-3 pt-1">
          {/* Sticky-note yellow category tag */}
          <span className="px-3 py-1 bg-[#FFD93D] text-[#1B3A5C] text-xs font-bold rounded-lg border border-[#1B3A5C]/40 shadow-2xs uppercase tracking-wider transform -rotate-1">
            {listing.category}
          </span>

          <div className="flex items-center gap-1.5">
            {/* Share Button (paper-plane / share icon) */}
            <button
              onClick={() => onShareListing(listing)}
              className="p-1.5 text-[#1B3A5C]/70 hover:text-[#E63946] hover:bg-[#1B3A5C]/5 rounded-full transition-colors cursor-pointer"
              title="Share listing"
              aria-label="Share listing"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {/* Heart / Favourite Doodle Icon */}
            <button
              onClick={() => onToggleFavourite(listing.id)}
              className={`p-1.5 rounded-full transition-transform active:scale-125 cursor-pointer ${
                isFavourite
                  ? 'text-[#E63946] fill-[#E63946]'
                  : 'text-[#1B3A5C]/60 hover:text-[#E63946]'
              }`}
              title={isFavourite ? 'Remove from favourites' : 'Add to favourites'}
              aria-label="Favorite listing"
            >
              <Heart className={`w-5 h-5 ${isFavourite ? 'fill-current text-[#E63946]' : ''}`} />
            </button>
          </div>
        </div>

        {/* Item Photo or Category Placeholder */}
        <div className="relative w-full h-48 bg-[#C9E2F5]/20 border border-[#1B3A5C]/15 rounded-xl overflow-hidden mb-3 flex items-center justify-center">
          {listing.imageBase64 && !imageError ? (
            <img
              src={listing.imageBase64}
              alt={listing.name}
              onError={() => setImageError(true)}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="flex flex-col items-center justify-center gap-2 p-4 text-center">
              {renderCategoryIcon(listing.category)}
              <span className="text-xs font-semibold text-[#1B3A5C]/60">
                {listing.category} Item
              </span>
            </div>
          )}

          {/* Condition Badge in Image Corner */}
          <span className="absolute bottom-2 left-2 px-2.5 py-0.5 bg-[#FAFBFC] text-[#1B3A5C] text-[11px] font-bold rounded-md border border-[#1B3A5C]/30 shadow-2xs">
            {listing.condition}
          </span>
        </div>

        {/* Title and Price */}
        <div className="mb-2">
          <h3 className="text-base font-extrabold text-[#1B3A5C] leading-snug line-clamp-2">
            {listing.name}
          </h3>
          <p className="text-xl font-black text-[#E63946] mt-1">
            ₹{listing.price.toLocaleString('en-IN')}
          </p>
        </div>

        {/* Description */}
        {listing.description && (
          <p className="text-xs text-[#1B3A5C]/80 line-clamp-2 mb-3 leading-relaxed">
            {listing.description}
          </p>
        )}
      </div>

      {/* Card Footer: Seller Info + Action Buttons */}
      <div className="pt-3 border-t border-dashed border-[#1B3A5C]/20 mt-2 space-y-2.5">
        
        {/* Seller Info */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            {listing.sellerPhoto ? (
              <img
                src={listing.sellerPhoto}
                alt={listing.sellerName}
                className="w-6 h-6 rounded-full object-cover border border-[#1B3A5C]/30"
              />
            ) : (
              <div className="w-6 h-6 rounded-full bg-[#1B3A5C] text-white flex items-center justify-center text-[10px] font-bold">
                {listing.sellerName?.[0] || 'S'}
              </div>
            )}
            <span className="font-semibold text-[#1B3A5C] truncate max-w-[120px]">
              {listing.sellerName}
            </span>
          </div>

          <span className="text-[10px] text-[#1B3A5C]/60 font-medium">
            Campus Peer
          </span>
        </div>

        {/* Action Button Row */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onMessageSeller(listing)}
            className="flex-1 py-2 px-3 bg-[#E63946] text-white font-bold text-xs rounded-full border border-[#1B3A5C] hover:bg-[#E63946]/90 transition-transform active:scale-95 shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Message seller</span>
          </button>

          {/* Delete Option for Seller */}
          {isSeller && onDeleteListing && (
            <button
              onClick={() => onDeleteListing(listing.id)}
              className="p-2 text-[#E63946] hover:bg-[#E63946]/10 border border-[#E63946]/30 rounded-full transition-colors cursor-pointer"
              title="Delete listing"
              aria-label="Delete listing"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
