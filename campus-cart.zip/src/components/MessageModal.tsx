import React, { useState } from 'react';
import { Listing, UserProfile } from '../types';
import { X, MessageSquare, Copy, Check, ExternalLink } from 'lucide-react';

interface MessageModalProps {
  listing: Listing | null;
  currentUser: UserProfile | null;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const MessageModal: React.FC<MessageModalProps> = ({
  listing,
  currentUser,
  onClose,
  onShowToast,
}) => {
  if (!listing) return null;

  const defaultMsg = `Hi ${listing.sellerName}! I saw your listing for "${listing.name}" (₹${listing.price}) on Campus Cart. Is it still available for pickup on campus?`;
  const [message, setMessage] = useState(defaultMsg);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    onShowToast('Message copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B3A5C]/40 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-lg bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl p-6 shadow-2xl animate-fadeIn"
        style={{ transform: 'rotate(-0.3deg)' }}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#1B3A5C]/60 hover:text-[#1B3A5C] p-1.5 rounded-xl hover:bg-[#1B3A5C]/5 cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          {listing.sellerPhoto ? (
            <img
              src={listing.sellerPhoto}
              alt={listing.sellerName}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#1B3A5C]"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-[#E63946] text-white font-bold flex items-center justify-center text-sm border-2 border-[#1B3A5C]">
              {listing.sellerName[0]}
            </div>
          )}
          <div>
            <h3 className="text-lg font-bold text-[#1B3A5C]">
              Message {listing.sellerName}
            </h3>
            <p className="text-xs text-[#1B3A5C]/70">
              Regarding: <span className="font-bold text-[#E63946]">{listing.name}</span> (₹{listing.price})
            </p>
          </div>
        </div>

        {/* Pre-filled Message Textarea */}
        <div className="mb-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-[#1B3A5C] mb-1.5">
            Your Note to Seller
          </label>
          <textarea
            rows={3}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full p-3 bg-white border-2 border-[#1B3A5C]/20 rounded-xl text-sm text-[#1B3A5C] focus:outline-none focus:border-[#E63946]"
          />
        </div>

        {/* Info Box */}
        <div className="p-3 bg-[#FFD93D]/40 border border-[#1B3A5C]/30 rounded-xl mb-5 text-xs text-[#1B3A5C] flex items-start gap-2">
          <MessageSquare className="w-4 h-4 text-[#E63946] flex-shrink-0 mt-0.5" />
          <span>Copy this message and send it directly via campus WhatsApp or email to close the deal quickly!</span>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={handleCopy}
            className="flex-1 py-2.5 px-4 bg-[#E63946] text-white font-bold text-xs rounded-full border-2 border-[#1B3A5C] hover:bg-[#E63946]/90 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied to Clipboard!' : 'Copy Pre-filled Message'}</span>
          </button>

          <button
            onClick={onClose}
            className="py-2.5 px-5 bg-white text-[#1B3A5C] font-semibold text-xs rounded-full border border-[#1B3A5C]/30 hover:bg-[#1B3A5C]/5 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
