import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, TabType } from '../types';
import { ShoppingBag, LogOut, Package, Heart, LogIn, ChevronDown, Pencil } from 'lucide-react';

interface NavbarProps {
  user: UserProfile | null;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  totalListingsCount: number;
  favouritesCount: number;
  myListingsCount: number;
  onOpenAuth: (actionText?: string) => void;
  onSignOut: () => void;
  onScrollToSell: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  setActiveTab,
  totalListingsCount,
  favouritesCount,
  myListingsCount,
  onOpenAuth,
  onSignOut,
  onScrollToSell
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-[#FAFBFC]/95 backdrop-blur-md border-b-2 border-[#1B3A5C]/15 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Left: Pencil doodle logo mark + Title */}
        <div 
          onClick={() => {
            setActiveTab('all');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-10 h-10 bg-[#FFD93D] border-2 border-[#1B3A5C] rounded-xl flex items-center justify-center transform -rotate-2 group-hover:rotate-3 transition-transform shadow-xs">
            <Pencil className="w-5 h-5 text-[#1B3A5C]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-handwriting text-2xl font-bold text-[#1B3A5C] tracking-wide">
                Campus Cart
              </span>
              <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 bg-[#E63946] text-white rounded-md tracking-wider">
                VIT
              </span>
            </div>
            <span className="hidden sm:block text-[11px] text-[#1B3A5C]/70 font-medium -mt-1">
              Notebook Marketplace
            </span>
          </div>
        </div>

        {/* Right Controls: Sell button + Cart icon + User / Sign in */}
        <div className="flex items-center gap-3">
          
          {/* Quick Sell CTA in Header */}
          <button
            onClick={onScrollToSell}
            className="hidden md:flex items-center gap-1.5 px-3.5 py-1.5 bg-[#FFD93D] text-[#1B3A5C] text-xs font-bold rounded-full border border-[#1B3A5C] hover:bg-[#FFD93D]/90 transition-all shadow-xs cursor-pointer"
          >
            <span>+ Sell Item</span>
          </button>

          {/* Cart Icon */}
          <div className="relative flex items-center justify-center w-10 h-10 bg-white border border-[#1B3A5C]/20 rounded-full shadow-2xs">
            <ShoppingBag className="w-5 h-5 text-[#1B3A5C]" />
            {totalListingsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#E63946] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                {totalListingsCount}
              </span>
            )}
          </div>

          {/* User Profile or Sign In Button */}
          {user ? (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 bg-white border-2 border-[#1B3A5C]/30 rounded-full shadow-2xs hover:border-[#1B3A5C] transition-all cursor-pointer"
                style={{ transform: 'rotate(-0.5deg)' }}
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.firstName}
                    className="w-6 h-6 rounded-full object-cover border border-[#1B3A5C]/20"
                  />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-[#E63946] text-white font-bold text-xs flex items-center justify-center">
                    {user.firstName[0]}
                  </div>
                )}
                <span className="text-xs font-bold text-[#1B3A5C]">
                  {user.firstName}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-[#1B3A5C]/60" />
              </button>

              {/* Dropdown Menu */}
              {dropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-48 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl shadow-xl py-2 z-50 animate-fadeIn"
                  style={{ transform: 'rotate(0.5deg)' }}
                >
                  <div className="px-4 py-2 border-b border-[#1B3A5C]/10 mb-1">
                    <p className="text-xs font-bold text-[#1B3A5C] truncate">{user.displayName}</p>
                    <p className="text-[10px] text-[#1B3A5C]/60 truncate">{user.email}</p>
                  </div>

                  <button
                    onClick={() => {
                      setActiveTab('my-listings');
                      setDropdownOpen(false);
                      const el = document.getElementById('listings-section');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full text-left px-4 py-2 text-xs font-semibold flex items-center justify-between hover:bg-[#1B3A5C]/5 cursor-pointer ${
                      activeTab === 'my-listings' ? 'text-[#E63946] font-bold' : 'text-[#1B3A5C]'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Package className="w-4 h-4" /> My Listings
                    </span>
                    <span className="bg-[#FFD93D] px-1.5 py-0.2 rounded-md text-[10px] text-[#1B3A5C]">
                      {myListingsCount}
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('favourites');
                      setDropdownOpen(false);
                      const el = document.getElementById('listings-section');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full text-left px-4 py-2 text-xs font-semibold flex items-center justify-between hover:bg-[#1B3A5C]/5 cursor-pointer ${
                      activeTab === 'favourites' ? 'text-[#E63946] font-bold' : 'text-[#1B3A5C]'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Heart className="w-4 h-4" /> My Favourites
                    </span>
                    <span className="bg-[#C9E2F5] px-1.5 py-0.2 rounded-md text-[10px] text-[#1B3A5C]">
                      {favouritesCount}
                    </span>
                  </button>

                  <div className="border-t border-[#1B3A5C]/10 my-1"></div>

                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      onSignOut();
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-[#E63946] flex items-center gap-2 hover:bg-[#E63946]/10 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => onOpenAuth('Sign in to post or message sellers')}
              className="px-4 py-2 bg-[#E63946] text-white text-xs font-bold rounded-full border-2 border-[#1B3A5C] hover:bg-[#E63946]/90 transition-transform active:scale-95 shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign in</span>
            </button>
          )}

        </div>

      </div>
    </header>
  );
};
