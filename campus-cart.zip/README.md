# Campus Cart — AI Campus Marketplace

Campus Cart is a single-page notebook-styled student-to-student marketplace for buying and selling used textbooks, campus cycles, calculators, and electronics.

Built live at the **VinnovateIT Vibe Coding Workshop**.

---

## 🎨 Theme & Palette

- **Paper White**: `#FAFBFC`
- **Checked-Grid Blue**: `#C9E2F5` (1px graph paper background pattern)
- **Ink Navy**: `#1B3A5C` (Body text & outline accents)
- **Notebook Red**: `#E63946` (Primary actions, marker stroke underlines, pill buttons)
- **Sticky-Note Yellow**: `#FFD93D` (Category tags, badges, sticky notes)

---

## 🚀 Features

1. **Notebook Graph Paper Aesthetic**: Floating coupon-styled forms, pinned index-card listings, red marker underlines, and handwritten display headers.
2. **Real-time Firestore Feed**: Live `onSnapshot` subscription ordered by `createdAt` descending.
3. **Domain Restricted Firebase Auth**: Restricted exclusively to official `@vitstudent.ac.in` student emails with Google OAuth and themed error feedback.
4. **Client-side Compressed Photo Upload**: Automatic canvas compression to JPEG base64 stored directly on Firestore documents.
5. **Interactive Controls**: Live live-counter, instantaneous search, category chip filtering, heart favourites saved to `localStorage`, native mobile share sheet integration, and seller messaging.

---

## ⚙️ Environment Variables

Copy `.env.example` to `.env` or declare the following environment variables in Vercel:

```env
VITE_FIREBASE_API_KEY="AIzaSyD6UQHmn8tVZAuInvdpf2HxVvv-5RY97ng"
VITE_FIREBASE_AUTH_DOMAIN="masterplace-26b20.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="masterplace-26b20"
VITE_FIREBASE_STORAGE_BUCKET="masterplace-26b20.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="781424968907"
VITE_FIREBASE_APP_ID="1:781424968907:web:a20ee6d3ba9e8f1586874e"
```

---

## 📦 Deployment Steps for Vercel

1. **Push Code to GitHub**:
   Push the project repository to your GitHub account.

2. **Import to Vercel**:
   - Go to [Vercel Dashboard](https://vercel.com/new) and select **Import Project**.
   - Choose your GitHub repository.

3. **Configure Build Settings**:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`

4. **Environment Variables**:
   Add all `VITE_FIREBASE_*` environment variables in the Vercel project settings.

5. **Deploy**:
   Click **Deploy**. Once complete, Vercel will give you a live production URL!

---

## 🛠️ Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

App runs on `http://localhost:3000`.
